------------------------------------------------------------
1. About background-green.png
------------------------------------------------------------
Name: background-green.png
Author: Danilo Gimenez
Licence: GNU Lesser General Public License
Last Updated: 26 Oct 2006
------------------------------------------------------------
2. HOWTO create a new background-green.png
------------------------------------------------------------
- Create a new image:
  - 1600 x 1200 / Portrait / RGB / Background
- Fill with a color or pattern:
  - on the new image window: SHIFT-B
  - on the "The Gimp" window:
    - click on the "background color"
    - hex triplet: c0ccd3
  - on the new image window: just click anywhere
- Create the fog effect:
  - Phyton-fu / Effects / Add fog
  - Click on "the colour of the fog"
  - Color name: #8098a8
  - The turbulence: 2
  - You can try "CTRL-Z" to undo the fog effect, and
    then redo it until you get a pleasant image
- Save as 
------------------------------------------------------------
3. About mad-tux-logo.png
------------------------------------------------------------
Name: mad-tux.png
Author: Pete Bradford
Licence: GNU Lesser General Public License
URL: http://art.gnome.org/themes/gdm_greeter/1282
Last Updated: 19 June 2006
------------------------------------------------------------
END OF FILE
------------------------------------------------------------
